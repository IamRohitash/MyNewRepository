Create table Employee(
E_Id int primary key,
E_Name varchar(50),
E_Salary varchar(20),
M_Id int)

Create table Manager(
M_Id int primary key,
M_Name varchar(50),
M_Salary varchar(20)
)


insert into Manager values(1,'Ramesh Kumar','50000'),(2,'Rahul Kumar','60000'),(3,'mahesh Kumar','40000'),(4,'Ram Singh','45000')
select * from Manager

insert into Employee values(1,'Pavan Kumar','50000',1),(2,'Aadity Kumar','60000',2),(3,'Manhash Singh','45000',2),(4,'Ramdev','45000',1)
select * from Employee

select e.E_Name,m.M_Name from Employee e
inner join Manager m
on e.M_Id=m.M_Id

Create or alter proc usp_OperationTwo
as
begin
     select m.M_Id,m.M_Name,count(e.M_Id) as 'No. Of Employees' from Manager m
     left join Employee e
     on m.M_Id=e.M_Id
     group by m.M_Name,m.M_Id
     order by m.M_Id asc
end


select  m.M_Name,count(e.M_Id) as 'No. Of Employees',m.M_Id from Manager m
left join Employee e
on m.M_Id=e.M_Id
group by m.M_Id,m.M_Name
order by m.M_Id asc

select M_Name,M_Salary from Manager



Select top(1) e.E_Id, e.E_Name, Max(e.E_Salary) as 'Salary',m.M_Name from Employee e 
inner join Manager m
on e.E_Id=m.M_Id
where e.E_Salary<(select Max(E_Salary) from Employee )
group by e.E_Name,m.M_Name,e.E_Id
order by Salary desc


Create or alter proc usp_OperationFour
as
begin
     Select top(1) e.E_Id, e.E_Name, Max(e.E_Salary) as 'Salary',m.M_Name from Employee e 
     inner join Manager m
     on e.E_Id=m.M_Id
     where e.E_Salary<(select Max(E_Salary) from Employee )
     group by e.E_Name,m.M_Name,e.E_Id
     order by Salary desc
end
