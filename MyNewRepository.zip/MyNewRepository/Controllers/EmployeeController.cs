﻿using MyTask.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyTask.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult RecordsWithAllPerameters()
        {
            BLLayer bl = new BLLayer();
            var allRecord=bl.GetAllEmployeeWithManager();
            ViewBag.data=allRecord;
            return View();
        }
        public ActionResult RecordsByOPOne()
        {
            BLLayer bl = new BLLayer();
            var allRecord = bl.GetAllRecordWithOPOne();
            ViewBag.data = allRecord;
            return View();
        }
        public ActionResult RecordsByOPTwo()
        {
            MyDatabaseEntities1 de1 = new MyDatabaseEntities1();
            var allRecord = de1.usp_OperationTwo().ToList();
            ViewBag.data = allRecord;
            return View();
        }

        public ActionResult RecordsByOPThree()
        {
            BLLayer bl = new BLLayer();
            var allRecord = bl.GetAllRecordWithOPThree();
            ViewBag.data = allRecord;
            return View();
        }
        public ActionResult RecordsByOPFour()
        {
            MyDatabaseEntities2 de2 = new MyDatabaseEntities2();
            var allRecord = de2.usp_OperationFour().ToList();
            ViewBag.data = allRecord;
            return View();
        }
    }
}