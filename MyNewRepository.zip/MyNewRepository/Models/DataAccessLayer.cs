﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MyTask.Models
{
    public class DataAccessLayer
    {
        public string OperationTwo()
        {

            SqlConnection con = null;
            string result = "";

            /* con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDatabaseEntities"].ToString());
             SqlCommand cmd = new SqlCommand("usp_OperationTwo", con);
             cmd.CommandType = CommandType.StoredProcedure;
             //cmd.Parameters.AddWithValue("@CustomerID", 0);    
            *//* cmd.Parameters.AddWithValue("@first_name", studentScore.FirstName);
             cmd.Parameters.AddWithValue("@last_name", studentScore.LastName);
             cmd.Parameters.AddWithValue("@class", studentScore.Class);
             cmd.Parameters.AddWithValue("@subject_Id", studentScore.StudentMarksListingRecords[0].Subject);
             cmd.Parameters.AddWithValue("@marks", studentScore.StudentMarksListingRecords[1].Marks);*//*
             con.Open();
             result = cmd.ExecuteScalar().ToString();
             return result;*/

            con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyDatabaseEntities"].ToString());
            SqlCommand cmd = new SqlCommand("usp_OperationTwo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //add any parameters the stored procedure might require
            con.Open();
            result = cmd.ExecuteScalar().ToString();
            return result;
            con.Close();
           
        
        }
    }
}