﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyTask.Models
{
    public class BLLayer
    {
        private MyDatabaseEntities db = new MyDatabaseEntities();

        public List<AllEmployeeWithManger> GetAllEmployeeWithManager()
        {
            var d = (from employee in db.Employees
                     join manager in db.Managers on
                   employee.M_Id equals manager.M_Id
                     select new AllEmployeeWithManger()
                     {
                         EmployeeID=employee.E_Id,
                         EmployeeName=employee.E_Name,
                         EmployeeSalary=employee.E_Salary,
                         ManagerId=manager.M_Id,
                         ManagerName=manager.M_Name,
                         ManagerSalary=manager.M_Salary,
                         
                     }).AsEnumerable().ToList();
            return  d;
        }



        public List<AllEmployeeWithManger> GetAllRecordWithOPOne()
        {
            var d = (from employee in db.Employees
                     join manager in db.Managers
                     on employee.E_Id equals manager.M_Id

                     select new AllEmployeeWithManger()
                     {
                         EmployeeID = manager.M_Id,
                         EmployeeName = manager.M_Name,
                         ManagerName = manager.M_Salary,
                     }).AsEnumerable().ToList();
            return d;
        }

        public List<AllEmployeeWithManger> GetAllRecordWithOPThree()
        {
            var d = (from manager in db.Managers
                     
                     select new AllEmployeeWithManger()
                     {
                         ManagerId = manager.M_Id,
                         ManagerName = manager.M_Name,
                         ManagerSalary = manager.M_Salary,
                     }).AsEnumerable().ToList();
            return d;
        }
        
    }
}