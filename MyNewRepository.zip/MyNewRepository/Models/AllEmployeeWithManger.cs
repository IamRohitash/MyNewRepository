﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyTask.Models
{
    public class AllEmployeeWithManger
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeSalary { get; set; }
        public int  ManagerId { get; set; }
        public string ManagerName { get; set; }
        public string ManagerSalary { get; set; }
    }
}